// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xconvolutional.h"

extern XConvolutional_Config XConvolutional_ConfigTable[];

XConvolutional_Config *XConvolutional_LookupConfig(u16 DeviceId) {
	XConvolutional_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCONVOLUTIONAL_NUM_INSTANCES; Index++) {
		if (XConvolutional_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XConvolutional_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XConvolutional_Initialize(XConvolutional *InstancePtr, u16 DeviceId) {
	XConvolutional_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XConvolutional_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XConvolutional_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

