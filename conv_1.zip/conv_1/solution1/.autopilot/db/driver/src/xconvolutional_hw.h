// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// CONTROL_BUS
// 0x0000 : Control signals
//          bit 0  - ap_start (Read/Write/COH)
//          bit 1  - ap_done (Read/COR)
//          bit 2  - ap_idle (Read)
//          bit 3  - ap_ready (Read)
//          bit 7  - auto_restart (Read/Write)
//          others - reserved
// 0x0004 : Global Interrupt Enable Register
//          bit 0  - Global Interrupt Enable (Read/Write)
//          others - reserved
// 0x0008 : IP Interrupt Enable Register (Read/Write)
//          bit 0  - Channel 0 (ap_done)
//          bit 1  - Channel 1 (ap_ready)
//          others - reserved
// 0x000c : IP Interrupt Status Register (Read/TOW)
//          bit 0  - Channel 0 (ap_done)
//          bit 1  - Channel 1 (ap_ready)
//          others - reserved
// 0x1000 ~
// 0x1fff : Memory 'image_r' (972 * 32b)
//          Word n : bit [31:0] - image_r[n]
// 0x2000 ~
// 0x21ff : Memory 'kernal' (81 * 32b)
//          Word n : bit [31:0] - kernal[n]
// 0x3000 ~
// 0x3fff : Memory 'out_r' (768 * 32b)
//          Word n : bit [31:0] - out_r[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_AP_CTRL      0x0000
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_GIE          0x0004
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_IER          0x0008
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_ISR          0x000c
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE 0x1000
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_HIGH 0x1fff
#define XCONVOLUTIONAL_CONTROL_BUS_WIDTH_IMAGE_R     32
#define XCONVOLUTIONAL_CONTROL_BUS_DEPTH_IMAGE_R     972
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE  0x2000
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_HIGH  0x21ff
#define XCONVOLUTIONAL_CONTROL_BUS_WIDTH_KERNAL      32
#define XCONVOLUTIONAL_CONTROL_BUS_DEPTH_KERNAL      81
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE   0x3000
#define XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_HIGH   0x3fff
#define XCONVOLUTIONAL_CONTROL_BUS_WIDTH_OUT_R       32
#define XCONVOLUTIONAL_CONTROL_BUS_DEPTH_OUT_R       768

