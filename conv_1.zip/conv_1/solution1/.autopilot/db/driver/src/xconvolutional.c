// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xconvolutional.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XConvolutional_CfgInitialize(XConvolutional *InstancePtr, XConvolutional_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_bus_BaseAddress = ConfigPtr->Control_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XConvolutional_Start(XConvolutional *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvolutional_ReadReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_AP_CTRL) & 0x80;
    XConvolutional_WriteReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XConvolutional_IsDone(XConvolutional *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvolutional_ReadReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XConvolutional_IsIdle(XConvolutional *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvolutional_ReadReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XConvolutional_IsReady(XConvolutional *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvolutional_ReadReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XConvolutional_EnableAutoRestart(XConvolutional *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvolutional_WriteReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_AP_CTRL, 0x80);
}

void XConvolutional_DisableAutoRestart(XConvolutional *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvolutional_WriteReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_AP_CTRL, 0);
}

u32 XConvolutional_Get_image_r_BaseAddress(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE);
}

u32 XConvolutional_Get_image_r_HighAddress(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_HIGH);
}

u32 XConvolutional_Get_image_r_TotalBytes(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + 1);
}

u32 XConvolutional_Get_image_r_BitWidth(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCONVOLUTIONAL_CONTROL_BUS_WIDTH_IMAGE_R;
}

u32 XConvolutional_Get_image_r_Depth(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCONVOLUTIONAL_CONTROL_BUS_DEPTH_IMAGE_R;
}

u32 XConvolutional_Write_image_r_Words(XConvolutional *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XConvolutional_Read_image_r_Words(XConvolutional *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XConvolutional_Write_image_r_Bytes(XConvolutional *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XConvolutional_Read_image_r_Bytes(XConvolutional *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_IMAGE_R_BASE + offset + i);
    }
    return length;
}

u32 XConvolutional_Get_kernal_BaseAddress(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE);
}

u32 XConvolutional_Get_kernal_HighAddress(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_HIGH);
}

u32 XConvolutional_Get_kernal_TotalBytes(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + 1);
}

u32 XConvolutional_Get_kernal_BitWidth(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCONVOLUTIONAL_CONTROL_BUS_WIDTH_KERNAL;
}

u32 XConvolutional_Get_kernal_Depth(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCONVOLUTIONAL_CONTROL_BUS_DEPTH_KERNAL;
}

u32 XConvolutional_Write_kernal_Words(XConvolutional *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XConvolutional_Read_kernal_Words(XConvolutional *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + (offset + i)*4);
    }
    return length;
}

u32 XConvolutional_Write_kernal_Bytes(XConvolutional *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XConvolutional_Read_kernal_Bytes(XConvolutional *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_KERNAL_BASE + offset + i);
    }
    return length;
}

u32 XConvolutional_Get_out_r_BaseAddress(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE);
}

u32 XConvolutional_Get_out_r_HighAddress(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_HIGH);
}

u32 XConvolutional_Get_out_r_TotalBytes(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + 1);
}

u32 XConvolutional_Get_out_r_BitWidth(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCONVOLUTIONAL_CONTROL_BUS_WIDTH_OUT_R;
}

u32 XConvolutional_Get_out_r_Depth(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCONVOLUTIONAL_CONTROL_BUS_DEPTH_OUT_R;
}

u32 XConvolutional_Write_out_r_Words(XConvolutional *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XConvolutional_Read_out_r_Words(XConvolutional *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XConvolutional_Write_out_r_Bytes(XConvolutional *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XConvolutional_Read_out_r_Bytes(XConvolutional *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_HIGH - XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_bus_BaseAddress + XCONVOLUTIONAL_CONTROL_BUS_ADDR_OUT_R_BASE + offset + i);
    }
    return length;
}

void XConvolutional_InterruptGlobalEnable(XConvolutional *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvolutional_WriteReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_GIE, 1);
}

void XConvolutional_InterruptGlobalDisable(XConvolutional *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvolutional_WriteReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_GIE, 0);
}

void XConvolutional_InterruptEnable(XConvolutional *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XConvolutional_ReadReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_IER);
    XConvolutional_WriteReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_IER, Register | Mask);
}

void XConvolutional_InterruptDisable(XConvolutional *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XConvolutional_ReadReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_IER);
    XConvolutional_WriteReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_IER, Register & (~Mask));
}

void XConvolutional_InterruptClear(XConvolutional *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvolutional_WriteReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_ISR, Mask);
}

u32 XConvolutional_InterruptGetEnabled(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XConvolutional_ReadReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_IER);
}

u32 XConvolutional_InterruptGetStatus(XConvolutional *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XConvolutional_ReadReg(InstancePtr->Control_bus_BaseAddress, XCONVOLUTIONAL_CONTROL_BUS_ADDR_ISR);
}

