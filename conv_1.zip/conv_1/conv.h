#include<stdio.h>
#ifndef CONV_H_
#define CONV_H_

#ifndef M
#define M 18        //size of image  18 *18 * 3
#endif

#ifndef N
#define N 3			// size of Kernel 3 * 3 * 3
#endif

#ifndef K
#define K 3       //number of kernels
#endif

void convolutional(int image[3][M][M],int kernal[K][N][N][N],int out[K][M - N + 1][M - N + 1]);

#endif
