
#include<stdio.h>
#include "conv.h"

int image[3][M][M] = { 0 };
int kernal[K][N][N][N] = { 0 };
int out[K][M - N + 1][M - N + 1] = { 0 };


//initialize the kernels
void init_kernals()
{
int a, b, c, d;
	for ( a = 0; a < K; ++a)
	{
		for ( b = 0; b < N; ++b)
		{
			for ( c = 0; c < N; ++c)
			{
				for ( d = 0; d < N; ++d)
				{
					kernal[a][b][c][d] = rand() % 3;
				}
			}

		}
	}
}

//generate the image randomly
void generate_matrix()
{
int i, row, col;
	for ( i = 0; i < 3; ++i)
	{
		for ( row = 1; row <= M - N + 1; ++row)
		{
			for ( col = 1; col <= M - N + 1; ++col)
			{
				image[i][row][col] = rand() % 10;
			}
		}
	}

}

void print_kernal()
{
int a, b, c, d;
	for ( a = 0; a < K; ++a)
	{
		for ( b = 0; b < N; ++b)
		{
			for ( c = 0; c < N; ++c)
			{
				for ( d = 0; d < N; ++d)
				{
					printf("%d ", kernal[a][b][c][d]);
				}
				printf("\n");
			}
			printf("\n");
		}
		printf("\n");
	}

}


void print_data()
{
int i, row, col;
	for  (i = 0; i < 3; ++i)
	{
		for ( row = 0; row < M; ++row)
		{
			for ( col = 0; col < M; ++col)
			{
				printf("%d ", image[i][row][col]);
			}
			printf("\n");
		}
		printf("\n");
	}
}

void print_out_data()
{
int ch, row, col;
	for ( ch = 0; ch < K;++ch)
	{
		for ( row = 0; row < M - N + 1; ++row)
		{
			for ( col = 0; col < M - N + 1; ++col)
			{
				printf("%d ", out[ch][row][col]);
			}
			printf("\n");
		}
		printf("\n");
	}

}

int main()
{
	generate_matrix();
	init_kernals();
	print_data();

	print_kernal();
	convolutional(image,kernal,out);
	print_out_data();
}

