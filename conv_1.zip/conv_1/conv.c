
#include<stdio.h>
#include "conv.h"

void convolutional(int image[3][M][M],int kernal[K][N][N][N],int out[K][M - N + 1][M - N + 1])  // one img, all kernals,int K, int M, int N
{
#pragma HLS INTERFACE s_axilite register port=image
#pragma HLS INTERFACE s_axilite register port=kernal
#pragma HLS INTERFACE s_axilite register port=out
#pragma HLS INTERFACE s_axilite port=return bundle=CONTROL_BUS
	int ch = 0;
	int row = 0;
	int col = 0;
	int temp = 0;
	int k, ax, ay, c;
	convolutional_label0:for ( k = 0; k < K; ++k)
	{
		convolutional_label1:for ( ax = 1; ax <= M - N + 1; ++ax)
		{
			convolutional_label2:for ( ay = 1; ay <= M - N + 1; ++ay)
			{
				convolutional_label3:for ( c = 0; c < 3; ++c) //each RGB channel
				{
                #pragma HLS PIPELINE II=1
					temp += image[c][ax - 1][ay - 1] * kernal[k][c][0][0] + image[c][ax - 1][ay] * kernal[k][c][0][1] + image[c][ax - 1][ay + 1] * kernal[k][c][0][2] +
						image[c][ax][ay - 1] * kernal[k][c][1][0] + image[c][ax][ay] * kernal[k][c][1][1] + image[c][ax][ay + 1] * kernal[k][c][1][2] +
						image[c][ax + 1][ay - 1] * kernal[k][c][2][0] + image[c][ax + 1][ay] * kernal[k][c][2][1] + image[c][ax + 1][ay + 1] * kernal[k][c][2][2];
				}

				out[ch][row][col] = temp;
				temp = 0;
				col++;
				if (col == M - N + 1)
				{
					col = 0;
					row++;
					if (row == M - N + 1)
					{
						row = 0;
						ch++;
					}

				}

			}
		}
	}

}


